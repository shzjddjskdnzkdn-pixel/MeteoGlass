export type CurrentWeather = {
  temperature: number; apparent: number; humidity: number; wind: number; gusts: number;
  pressure: number; code: number; isDay: number; uv: number; visibility: number;
};
export type Hour = { time: string; temperature: number; precipitation: number; probability: number; code: number; wind: number };
export type Day = { date: string; min: number; max: number; precipitation: number; probability: number; code: number; sunrise: string; sunset: string };
export type WeatherPayload = { current: CurrentWeather; hourly: Hour[]; daily: Day[]; timezone: string; updatedAt: string };

export function weatherLabel(code: number) {
  if (code === 0) return 'Ciel dégagé';
  if ([1,2].includes(code)) return 'Peu nuageux';
  if (code === 3) return 'Couvert';
  if ([45,48].includes(code)) return 'Brouillard';
  if ([51,53,55,56,57].includes(code)) return 'Bruine';
  if ([61,63,65,66,67,80,81,82].includes(code)) return 'Pluie';
  if ([71,73,75,77,85,86].includes(code)) return 'Neige';
  if ([95,96,99].includes(code)) return 'Orages';
  return 'Conditions variables';
}
export function weatherIcon(code: number) {
  if ([0,1].includes(code)) return '☀️';
  if ([2,3,45,48].includes(code)) return '☁️';
  if ([51,53,55,56,57,61,63,65,66,67,80,81,82].includes(code)) return '🌧️';
  if ([71,73,75,77,85,86].includes(code)) return '❄️';
  if ([95,96,99].includes(code)) return '⛈️';
  return '🌤️';
}
