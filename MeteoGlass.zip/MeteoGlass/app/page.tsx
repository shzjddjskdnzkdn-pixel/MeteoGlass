'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Activity, AlertTriangle, ArrowDown, ArrowUp, CalendarDays, ChevronDown, Cloud, CloudDrizzle, CloudRain, CloudSun, Compass, Droplets, Gauge, LocateFixed, MapPin, Menu, Moon, Search, Sun, Sunrise, Sunset, Thermometer, Wind, X } from 'lucide-react';
import { weatherIcon, weatherLabel } from '@/lib/weather';

type Place = { name: string; admin?: string; country?: string; lat: number; lon: number };
type Weather = any;
const defaultPlace: Place = { name: 'Paris', admin: 'Île-de-France', country: 'France', lat: 48.8566, lon: 2.3522 };
const fmt = (n: number) => Math.round(n);
const hour = (s: string) => new Date(s).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
const day = (s: string) => new Date(`${s}T12:00:00`).toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric' });

export default function Home() {
  const [place, setPlace] = useState<Place>(defaultPlace);
  const [weather, setWeather] = useState<Weather | null>(null);
  const [loading, setLoading] = useState(true);
  const [updated, setUpdated] = useState<Date | null>(null);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Place[]>([]);
  const [searchOpen, setSearchOpen] = useState(false);
  const [tab, setTab] = useState<'overview'|'forecast'|'vigilance'>('overview');
  const [geoMessage, setGeoMessage] = useState('');
  const [clock, setClock] = useState(new Date());

  useEffect(() => {
    const saved = localStorage.getItem('meteoglass-place');
    if (saved) { try { setPlace(JSON.parse(saved)); } catch {} }
    const t = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  const loadWeather = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch(`/api/weather?lat=${place.lat}&lon=${place.lon}`, { cache: 'no-store' });
      if (!r.ok) throw new Error('Météo indisponible');
      setWeather(await r.json()); setUpdated(new Date());
    } catch { setGeoMessage('Impossible de récupérer les dernières données météo. Réessaie dans quelques instants.'); }
    finally { setLoading(false); }
  }, [place]);
  useEffect(() => { loadWeather(); const id = setInterval(loadWeather, 5 * 60 * 1000); return () => clearInterval(id); }, [loadWeather]);
  useEffect(() => {
    if (query.trim().length < 2) { setResults([]); return; }
    const id = setTimeout(async () => { try { const r = await fetch(`/api/geocode?q=${encodeURIComponent(query)}`); setResults(await r.json()); } catch { setResults([]); } }, 280);
    return () => clearTimeout(id);
  }, [query]);
  const choosePlace = (p: Place) => { setPlace(p); localStorage.setItem('meteoglass-place', JSON.stringify(p)); setSearchOpen(false); setQuery(''); setResults([]); setGeoMessage(''); };
  const locate = () => {
    if (!navigator.geolocation) { setGeoMessage('La géolocalisation n’est pas disponible sur cet appareil.'); return; }
    navigator.geolocation.getCurrentPosition(pos => choosePlace({ name: 'Ma position', lat: pos.coords.latitude, lon: pos.coords.longitude, country: 'France' }), () => setGeoMessage('Autorise la localisation dans ton navigateur ou recherche une ville.'));
  };
  const current = weather?.current;
  const today = weather?.daily?.[0];
  const hourly = useMemo(() => (weather?.hourly ?? []).filter((x: any) => new Date(x.time).getTime() >= Date.now()).slice(0, 24), [weather]);
  const daily = weather?.daily ?? [];
  return <main className="shell">
    <div className="ambient ambient-one"/><div className="ambient ambient-two"/>
    <header className="topbar">
      <a className="brand" href="#top"><span className="brand-mark"><CloudSun size={22}/></span><span>Meteo<span className="brand-light">Glass</span><small>LA MÉTÉO EN CLAIR</small></span></a>
      <nav className="nav"><button className={tab==='overview'?'active':''} onClick={()=>setTab('overview')}>Aujourd’hui</button><button className={tab==='forecast'?'active':''} onClick={()=>setTab('forecast')}>Prévisions</button><button className={tab==='vigilance'?'active':''} onClick={()=>setTab('vigilance')}>Vigilances</button></nav>
      <div className="top-actions"><button className="icon-button" aria-label="Me géolocaliser" onClick={locate}><LocateFixed size={18}/></button><button className="location-button" onClick={()=>setSearchOpen(!searchOpen)}><MapPin size={16}/><span>{place.name}</span><ChevronDown size={15}/></button></div>
    </header>
    {searchOpen && <section className="search-panel glass"><div className="search-input"><Search size={18}/><input autoFocus placeholder="Rechercher une ville…" value={query} onChange={e=>setQuery(e.target.value)}/><button onClick={()=>setSearchOpen(false)}><X size={17}/></button></div>{results.map((r,i)=><button className="search-result" key={i} onClick={()=>choosePlace(r)}><MapPin size={16}/><span>{r.name}<small>{[r.admin,r.country].filter(Boolean).join(', ')}</small></span></button>)}{query.length>1 && results.length===0 && <p className="empty-search">Recherche d’une ville…</p>}</section>}
    <section className="hero" id="top">
      <div className="hero-copy"><div className="eyebrow"><span className="live-dot"/> MÉTÉO LOCALE <span className="eyebrow-line"/></div><h1>{place.name}<span className="location-sub">{place.admin || place.country || 'Votre météo'}</span></h1><div className="date-line">{clock.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'})} <span>·</span> {clock.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})}</div>
        {current ? <><div className="temperature">{fmt(current.temperature_2m)}<sup>°</sup></div><div className="condition">{weatherIcon(current.weather_code)} <span>{weatherLabel(current.weather_code)}</span></div><div className="feels">Ressenti {fmt(current.apparent_temperature)}° · H {fmt(today?.temperature_2m_max)}° / B {fmt(today?.temperature_2m_min)}°</div></> : <div className="loading-temp">{loading?'Chargement de la météo…':'Données momentanément indisponibles'}</div>}
      </div>
      <div className="hero-art"><div className="sun-halo"/><div className="hero-weather-icon">{current ? weatherIcon(current.weather_code) : '🌤️'}</div><div className="floating-cloud cloud-a">☁️</div><div className="floating-cloud cloud-b">☁️</div><div className="hero-orbit orbit-a"/><div className="hero-orbit orbit-b"/></div>
      <div className="hero-footer"><span><Activity size={14}/> Conditions en direct</span><span>{updated ? `Actualisé à ${updated.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})}` : 'Connexion aux données météo'}</span><button onClick={loadWeather}>↻ Actualiser</button></div>
    </section>
    {geoMessage && <div className="notice"><AlertTriangle size={16}/>{geoMessage}<button onClick={()=>setGeoMessage('')}><X size={15}/></button></div>}
    {tab==='overview' && <>
      <div className="section-heading"><div><span className="eyebrow">VOTRE JOURNÉE</span><h2>En un coup d’œil</h2></div><span className="muted">Données météo · actualisation auto. 5 min</span></div>
      <section className="metric-grid">
        <Metric icon={<Thermometer/>} label="Ressenti" value={current?`${fmt(current.apparent_temperature)}°`:'—'} detail="Température ressentie"/>
        <Metric icon={<Droplets/>} label="Humidité" value={current?`${fmt(current.relative_humidity_2m)}%`:'—'} detail="Humidité relative"/>
        <Metric icon={<Wind/>} label="Vent" value={current?`${fmt(current.wind_speed_10m)} km/h`:'—'} detail={current?`Rafales ${fmt(current.wind_gusts_10m)} km/h`:'Vitesse moyenne'}/>
        <Metric icon={<Gauge/>} label="Pression" value={current?`${fmt(current.surface_pressure)} hPa`:'—'} detail="Pression atmosphérique"/>
      </section>
      <section className="glass hourly-card"><div className="card-heading"><div><span className="eyebrow">LES PROCHAINES HEURES</span><h3>Prévisions horaires</h3></div><button className="text-link" onClick={()=>setTab('forecast')}>Voir 10 jours <ArrowUp size={14}/></button></div><div className="hourly-scroll">{hourly.map((h:any,i:number)=><div className="hour-item" key={h.time}><span className="hour-time">{i===0?'Maint.':hour(h.time)}</span><span className="hour-icon">{weatherIcon(h.weather_code)}</span><b>{fmt(h.temperature_2m)}°</b><span className="rain-prob"><Droplets size={11}/>{h.precipitation_probability ?? 0}%</span></div>)}</div></section>
      <section className="lower-grid"><div className="glass detail-card"><div className="card-heading"><div><span className="eyebrow">SOLEIL</span><h3>Le rythme du jour</h3></div><Sun size={19}/></div><div className="sun-times"><div><Sunrise/><span><small>Lever du soleil</small><b>{today?hour(today.sunrise):'—'}</b></span></div><div className="sun-arc"><span/></div><div><Sunset/><span><small>Coucher du soleil</small><b>{today?hour(today.sunset):'—'}</b></span></div></div></div><div className="glass detail-card"><div className="card-heading"><div><span className="eyebrow">INDICE UV</span><h3>Rayonnement solaire</h3></div><Sun size={19}/></div><div className="uv-value">{today?.uv_index_max ?? '—'}<span>/ 11+</span></div><div className="uv-track"><span style={{width:`${Math.min(100,((today?.uv_index_max ?? 0)/11)*100)}%`}}/></div><p className="small-muted">Indice UV maximal prévu aujourd’hui</p></div></section>
    </>}
    {tab==='forecast' && <><div className="section-heading"><div><span className="eyebrow">TENDANCE MÉTÉO</span><h2>Les 10 prochains jours</h2></div></div><section className="glass forecast-card">{daily.map((d:any,i:number)=><div className="forecast-row" key={d.date}><span className="forecast-day">{i===0?'Aujourd’hui':day(d.date)}</span><span className="forecast-icon">{weatherIcon(d.weather_code)}</span><span className="forecast-rain"><Droplets size={13}/>{d.precipitation_probability_max ?? 0}%</span><span className="forecast-min">{fmt(d.temperature_2m_min)}°</span><span className="temp-bar"><i style={{left:`${Math.max(0,Math.min(85,(d.temperature_2m_min+5)*2))}%`,width:`${Math.max(12,Math.min(90,(d.temperature_2m_max-d.temperature_2m_min)*3))}%`}}/></span><b>{fmt(d.temperature_2m_max)}°</b></div>)}</section></>}
    {tab==='vigilance' && <><div className="section-heading"><div><span className="eyebrow">SÉCURITÉ MÉTÉO</span><h2>Vigilances en France</h2></div><span className="muted">Bulletins officiels</span></div><section className="glass vigilance-intro"><div className="vigilance-symbol"><AlertTriangle size={26}/></div><div><h3>Suivre les alertes départementales</h3><p>Les vigilances officielles sont publiées par Météo-France. Connecte la source officielle dans la configuration du projet pour afficher les niveaux, phénomènes, horaires et bulletins en temps réel.</p></div></section><div className="vigilance-levels"><div className="level level-green"><i/>Vert <small>Pas de vigilance particulière</small></div><div className="level level-yellow"><i/>Jaune <small>Soyez attentif</small></div><div className="level level-orange"><i/>Orange <small>Soyez très vigilant</small></div><div className="level level-red"><i/>Rouge <small>Une vigilance absolue s’impose</small></div></div><section className="glass source-card"><div className="source-top"><div><span className="eyebrow">ÉTAT DE CONNEXION</span><h3>Sources de vigilance</h3></div><span className="status-pill pending">À configurer</span></div><p>La clé API et l’URL d’accès Météo-France doivent être ajoutées dans les variables d’environnement Vercel. Tant que ce branchement n’est pas configuré, aucun niveau de vigilance n’est inventé ou présenté comme officiel.</p><a href="https://vigilance.meteofrance.fr/fr" target="_blank" rel="noreferrer" className="source-link">Consulter la carte officielle Météo-France ↗</a></section></>}
    <footer className="footer"><div className="footer-brand">Meteo<span>Glass</span></div><p>La météo en clair. Des prévisions utiles, une interface limpide.</p><div className="footer-meta"><span>Conditions météo : Open-Meteo</span><span>·</span><a href="https://meteociel.fr" target="_blank" rel="noreferrer">Météociel</a><span>·</span><a href="https://meteofrance.com" target="_blank" rel="noreferrer">Météo-France</a></div><small>Les prévisions sont indicatives. En cas de danger, référez-vous aux bulletins officiels.</small></footer>
  </main>;
}
function Metric({icon,label,value,detail}:{icon:React.ReactNode;label:string;value:string;detail:string}) { return <div className="glass metric-card"><div className="metric-top"><span>{icon}</span><small>{label}</small></div><strong>{value}</strong><p>{detail}</p></div>; }
