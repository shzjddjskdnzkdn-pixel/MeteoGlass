import { NextRequest, NextResponse } from 'next/server';
export async function GET(req: NextRequest) {
  const q = new URL(req.url).searchParams.get('q')?.trim();
  if (!q || q.length < 2) return NextResponse.json([]);
  const url = new URL('https://geocoding-api.open-meteo.com/v1/search');
  url.search = new URLSearchParams({ name: q, count: '6', language: 'fr', format: 'json' }).toString();
  try {
    const r = await fetch(url, { next: { revalidate: 86400 } });
    const data = await r.json();
    return NextResponse.json((data.results ?? []).map((x: any) => ({ id: `${x.latitude},${x.longitude}`, name: x.name, admin: x.admin1, country: x.country, lat: x.latitude, lon: x.longitude })));
  } catch { return NextResponse.json([], { status: 502 }); }
}
