import { NextRequest, NextResponse } from 'next/server';
export const revalidate = 0;
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const lat = Number(searchParams.get('lat') ?? 48.8566);
  const lon = Number(searchParams.get('lon') ?? 2.3522);
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) {
    return NextResponse.json({ error: 'Coordonnées invalides' }, { status: 400 });
  }
  const url = new URL('https://api.open-meteo.com/v1/forecast');
  url.search = new URLSearchParams({
    latitude: String(lat), longitude: String(lon), timezone: 'auto', forecast_days: '10',
    current: 'temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m,wind_gusts_10m,surface_pressure',
    hourly: 'temperature_2m,precipitation_probability,precipitation,weather_code,wind_speed_10m,visibility',
    daily: 'weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,precipitation_sum,precipitation_probability_max,uv_index_max'
  }).toString();
  try {
    const response = await fetch(url, { next: { revalidate: 300 } });
    if (!response.ok) throw new Error(`Weather provider returned ${response.status}`);
    return NextResponse.json(await response.json(), { headers: { 'Cache-Control': 's-maxage=300, stale-while-revalidate=600' } });
  } catch {
    return NextResponse.json({ error: 'Le service météo est temporairement indisponible.' }, { status: 502 });
  }
}
