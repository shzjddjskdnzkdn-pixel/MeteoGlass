import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'MeteoGlass — La météo en clair', description: 'Météo locale, prévisions et vigilances météorologiques en France.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="fr"><body>{children}</body></html>;
}
