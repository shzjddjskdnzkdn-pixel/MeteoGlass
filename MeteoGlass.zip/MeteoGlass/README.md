# MeteoGlass

Application météo française Next.js avec interface Liquid Glass, recherche de ville, géolocalisation facultative, prévisions horaires et 10 jours, et espace de vigilances.

## Démarrer en local

Prérequis : Node.js 20.9+.

```bash
npm install
cp .env.example .env.local
npm run dev
```

Ouvre http://localhost:3000.

## Données et transparence

- **Météo actuelle et prévisions** : l'application interroge actuellement Open-Meteo côté serveur (cache 5 minutes). L'interface affiche les liens Météo-France et Météociel comme ressources complémentaires, mais ne prétend pas consommer leurs flux privés.
- **Météo-France Vigilance** : la page Vigilances est préparée, mais le flux officiel doit être raccordé avec les accès et l'URL exacts fournis par Météo-France. Les identifiants ne doivent jamais être exposés dans le navigateur. Tant que la connexion n'est pas configurée, le site indique explicitement que les niveaux ne sont pas disponibles plutôt que d'inventer une alerte.
- **Météociel** : aucune API publique stable et autorisée n'est présumée. Ajouter un adaptateur uniquement avec une API, un flux ou une autorisation documentée.

## Déploiement GitHub + Vercel

1. Crée un nouveau dépôt GitHub nommé `MeteoGlass`.
2. Dépose le contenu de ce dossier à la racine du dépôt, puis commit/push sur `main`.
3. Dans Vercel, choisis **Add New → Project**, importe le dépôt `MeteoGlass`, conserve les paramètres Next.js par défaut, puis déploie.
4. Ajoute les variables d'environnement nécessaires dans **Project → Settings → Environment Variables**. Les variables facultatives de vigilance ne sont à ajouter qu'après obtention des accès officiels.
5. Chaque push sur `main` déclenchera un déploiement de production sur la même URL Vercel. Les déploiements précédents restent accessibles dans l'historique.

## Mise à jour automatique

Le navigateur actualise les conditions météo toutes les 5 minutes et le serveur utilise un cache de 5 minutes. Les mises à jour de code sont automatiques à chaque push GitHub sur `main`. Les vigilances ne sont pas encore branchées : ne pas présenter cet espace comme un bulletin officiel tant que l'API Météo-France n'est pas connectée.

## À compléter avant une mise en production publique

- Raccorder l'API officielle Météo-France Vigilance avec son contrat et son format de réponse actuels.
- Confirmer les droits d'accès et conditions de réutilisation de toute donnée Météociel utilisée.
- Ajouter une carte départementale fondée sur un jeu de données géographiques dont la licence autorise la redistribution.
- Ajouter une supervision des sources et un horodatage spécifique par flux.
